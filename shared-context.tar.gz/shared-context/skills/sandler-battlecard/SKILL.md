---
name: sandler-sales-intelligence
description: Generate Sandler-aligned sales intelligence briefs, battlecards, and prospect profiles for B2B outreach in New Zealand ICT/Digital resourcing. Use when the user requests research on a company or individual for sales outreach, asks to create battlecards or playbooks, or mentions Sandler methodology, prospect qualification, or pain discovery.
---

# Sandler Sales Intelligence

Generate high-fidelity sales intelligence using the Sandler Sales Methodology for Lexel Resourcing's B2B outreach in New Zealand.

## Core Principles

**Sandler Alignment**:
- Focus on Pain: Uncover, validate, and quantify prospect's deep organisational or personal pain
- No Selling, Only Qualifying: Identify if prospect is a good fit or time-waster
- Budget, Authority, Need, Timeline (BANT): Qualify systematically

**Output Standards**:
- Use New Zealand spelling (organisational, realise, judgement, optimisation)
- Maintain cynical yet truthful, high-fidelity tone
- Cross-reference all findings with ICP segments in `references/icp-segments.md`
- Apply Data Integrity Gate: If insufficient public data exists for personality profiling, return Low-Fidelity Warning

## Workflow

### When to Use Each Research Type

**Company Research** (`@Research` equivalent):
- User asks: "Research [Company Name]" or "[Company] for outreach?"
- Provides strategic organisational assessment

**Person Profiling** (`@Person` equivalent):
- User asks: "Research [Person Name] @ [Company]" or provides LinkedIn profile
- Provides psychological/DISC profiling for individuals

**Both** (Full Battlecard):
- User asks for "battlecard" or comprehensive outreach package
- Combines company + key decision-maker profiles

### Step 1: Company Research

Always use web_search and recent_chats tools extensively (minimum 5-8 searches) to gather:

1. **Company Overview**: Industry, size, locations, recent news, financial performance
2. **Technology Stack**: Current systems, recent implementations, technical debt signals
3. **Organisational Pain Discovery**:
   - Match company size and industry to ICP segments in `references/icp-segments.md`
   - Identify specific pain points from segment profile
   - Find public evidence (news, job postings, reviews, financial reports)
4. **Decision-Maker Hypotheses**: 
   - Identify 2-3 likely Pain Owners/Technical Gatekeepers
   - Prioritise functional leaders over C-Suite (e.g., Head of I&O, Technical Lead, GM Applications)
   - Focus on those with budget for Cloud Security, DevOps/SRE, Infrastructure & Operations

**Output Template: Company Brief**

```
## [COMPANY NAME] - Strategic Brief

**TL;DR**: [One-sentence challenge summary]

### Organisational Pain (Sandler)
[Top 2-3 business problems Lexel Resourcing solves, with evidence]

1. **[Pain Point 1]**
   - Evidence: [Specific public data points]
   - Lexel Solution Fit: [Reference ICP segment]

2. **[Pain Point 2]**
   - Evidence: [Specific public data points]
   - Lexel Solution Fit: [Reference ICP segment]

### Decision-Maker Hypotheses (DMP)
[2-3 most likely Pain Owners with tactical budget responsibility]

- **[Name]** - [Title]: [Why they own this pain]
- **[Name]** - [Title]: [Why they own this pain]

### Engagement Strategy (Sandler)
**Opening Question**: [Specific, non-pushy question to surface pain]
Example: "I noticed [evidence of pain] - how is your team currently handling [specific challenge]?"

### ICP Alignment
**Segment**: [20-100 / 100-500 / 500+ seats] - [Healthcare/Financial/Manufacturing/Property/Utilities]
**Key Characteristics**: [Reference from icp-segments.md]
```

### Step 2: Person Profiling

**Data Integrity Gate**: Require un-redacted public profile (LinkedIn, corporate bio, news interview) with evidence for at least 3 of 6 personality sections. If insufficient data, return Low-Fidelity Warning.

Use web_search extensively (5-8+ searches) to gather:
- Professional history, education, career trajectory
- Public statements, articles, interviews, social media
- Projects led, technologies championed, budget decisions
- Communication style, industry reputation

Consult `references/personality-frameworks.md` for profiling guidance.

**Output Template: Person Profile**

```
## [PERSON NAME] @ [COMPANY] - Individual Profile

**TL;DR**: [2-sentence headline insight]

### DISC Type Guess
**Primary**: [D/I/S/C]
**Rationale**: [Evidence from public data]
[Reference DISC characteristics from personality-frameworks.md]

### Game Being Played
[Overarching objective they pursue - career advancement, technical mastery, risk mitigation, etc.]

### Rider vs. Elephant
**Rider (Conscious Narrative)**: [What they say/present publicly]
**Elephant (Core Drives)**: [Underlying motivations/compulsions]

### OCEAN Big Five Snapshot
[Consult personality-frameworks.md for interpretation]

- **Openness**: [High/Low] - [Evidence]
- **Conscientiousness**: [High/Low] - [Evidence]
- **Extraversion**: [High/Low] - [Evidence]
- **Agreeableness**: [High/Low] - [Evidence]
- **Neuroticism**: [High/Low] - [Evidence]

### Key Questions to Ask Next (Sandler)
1. [Pain discovery question]
2. [Budget qualification question]
3. [Decision process question]
4. [Timeline question]
5. [Technical requirement question]

### Metacognition
**Confidence Level**: [High/Medium/Low]
**Biases Noted**: [Your analytical assumptions]
**Data Gaps**: [Missing information that would improve profile]
```

**Low-Fidelity Warning Output** (when Data Integrity Gate triggered):

```
## [PERSON NAME] @ [COMPANY] - Low-Fidelity Warning

**Verdict**: ⚠️ No Actionable Insight - Insufficient Public Data

### Data Gap
[Specific data missing - e.g., "No confirmed professional history or public profile found"]

### Required Pivot
Suggest alternative data-rich prospects based on Company Brief pain points:

1. **[Alternative Name]** - [Title]: [Why better data available]
2. **[Alternative Name]** - [Title]: [Why better data available]
3. **[Alternative Name]** - [Title]: [Why better data available]
```

## Response Guidelines

- Lead with TL;DR for scannability
- Use bold for key terms and names
- Cite specific evidence (job postings, news articles, financial reports)
- Maintain cynical-but-truthful tone: "likely struggling with X" rather than "definitely has pain point X"
- Always cross-reference ICP segments to validate pain hypotheses
- Use Sandler terminology: Pain, Budget, Authority, Need, Timeline
- For New Zealand companies, note cultural/regional factors

## Resources

- `references/icp-segments.md` - Lexel's Ideal Customer Profiles and segment pain points
- `references/sandler-framework.md` - Sandler Sales Methodology principles and questioning techniques
- `references/personality-frameworks.md` - DISC, OCEAN, Rider/Elephant profiling guidance
