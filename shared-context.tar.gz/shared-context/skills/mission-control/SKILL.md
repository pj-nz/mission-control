---
name: mission-control
description: Initialize multi-model orchestration environment by pulling shared-context from GitHub. Use when PJ says "mission control", "start mission control", "initialize orchestration", or "pull the context".
---

# Mission Control

Initialize the orchestration environment by pulling shared-context from GitHub.

## Trigger Phrases
- "mission control"
- "start mission control"
- "initialize orchestration"
- "pull the context"
- "boot up"

## Repository
- **GitHub:** `https://github.com/pj-nz/mission-control` (public)
- **Required allowlist domains:**
  - `github.com`
  - `codeload.github.com` (for zip downloads)
  - `raw.githubusercontent.com` (for raw file fetch)

## Workflow

### Step 1: Fetch from GitHub

**Method A: Download as ZIP (preferred)**
```bash
cd /home/claude
curl -L -o mc.zip "https://github.com/pj-nz/mission-control/archive/refs/heads/main.zip"
unzip -q mc.zip
mv mission-control-main shared-context
rm mc.zip
```

**Method B: Git clone (if git works)**
```bash
cd /home/claude
git clone https://github.com/pj-nz/mission-control.git shared-context
```

**Method C: Fallback - user uploads .tar.gz**
```bash
cd /home/claude
tar -xzvf /mnt/user-data/uploads/shared-context.tar.gz
```

### Step 2: Verify Structure
```bash
python3 /home/claude/shared-context/load_context.py --list-skills
python3 /home/claude/shared-context/load_context.py --list-projects
```

### Step 3: Load Current State
- Check `projects/_active.json` for active projects
- Read recent entries from `memory/decisions.md`
- Check project `history.md` files for last actions

### Step 4: Report Status
```
Mission Control Online.

Skills: [list]
Active Projects: [list]  
Last Decision: [date] - [summary]

Ready for instructions.
```

## End of Session Protocol

Before closing chat:

### 1. Update State
```bash
# Update decisions log
echo "## $(date -u +%Y-%m-%d) | [Summary]" >> /home/claude/shared-context/memory/decisions.md

# Update project history if worked on
echo "## $(date -u +%Y-%m-%d) UTC\n**Action:** [what]\n**Outcome:** [result]" >> /home/claude/shared-context/projects/[project]/history.md
```

### 2. Commit & Push
```bash
cd /home/claude/shared-context
git add -A
git commit -m "Session update: $(date +%Y-%m-%d) - [brief summary]"
git push
```

### 3. Export Backup
```bash
cd /home/claude
tar -czvf shared-context.tar.gz shared-context/
cp shared-context.tar.gz /mnt/user-data/outputs/
```

### 4. Confirm
"Context pushed to GitHub. Backup .tar available for download."

## Repository Structure
```
github.com/pj-nz/claude-orchastrator/
├── skills/
│   ├── _index.json
│   ├── linkedin-candidate-card/
│   ├── weekly-market-email/
│   ├── sandler-battlecard/
│   ├── orchestration-resume/
│   └── mission-control/
├── memory/
│   ├── user.md
│   ├── entities.json
│   └── decisions.md
├── projects/
│   ├── _active.json
│   ├── voice-agent/
│   └── notion-sync/
├── templates/
├── inbox/
├── load_context.py
├── ORCHESTRATION.md
└── README.md
```

## Authentication Options

### Option A: Public Repo
No auth needed. Just clone.

### Option B: Private Repo + Token
```bash
git clone https://[TOKEN]@github.com/pj-nz/claude-orchastrator.git
```
Or PJ provides token at session start.

### Option C: Private Repo + SSH (if configured)
```bash
git clone git@github.com:pj-nz/claude-orchastrator.git
```

## Quick Reference

| Command | Action |
|---------|--------|
| "mission control" | Initialize session |
| "status" | Show active projects + recent decisions |
| "save and close" | Commit, push, export backup |
| "list skills" | Show available skills |
| "list projects" | Show active projects |

## Fallback

If GitHub unavailable:
1. Ask PJ to upload `shared-context.tar.gz`
2. Extract: `tar -xzvf /mnt/user-data/uploads/shared-context.tar.gz -C /home/claude/`
3. Continue normally

---

*Mission Control is the entry point. Everything else flows from here.*

---

## Sharing With Others

Anyone can use this orchestration setup:

### Option 1: Fork the Repo
1. Fork `https://github.com/pj-nz/mission-control`
2. Customize `memory/user.md` with their own context
3. Add their own skills to `skills/`
4. In Claude chat: "mission control" → Claude pulls from their fork

### Option 2: Download and Upload
1. Download zip from `https://github.com/pj-nz/mission-control`
2. Extract, customize `memory/user.md`
3. Re-zip or tar: `tar -czvf shared-context.tar.gz shared-context/`
4. Upload to Claude chat → say "mission control"

### Required Claude Settings
For GitHub pull to work, add these to Claude network allowlist:
- `github.com`
- `codeload.github.com`
- `raw.githubusercontent.com`

### What to Customize
| File | Purpose | Personalize? |
|------|---------|--------------|
| `memory/user.md` | Who you are, preferences | **Yes** |
| `memory/entities.json` | Your tools, companies, keys | **Yes** |
| `skills/*` | Skill definitions | Add your own |
| `projects/*` | Active workstreams | **Yes** |
| `ORCHESTRATION.md` | Architecture reference | Optional |

### Minimal Setup
At minimum, edit `memory/user.md`:
```markdown
# User: [Your Name]

## Role
[Your job/context]

## Communication Style
[How you like responses]

## Current Focus
[What you're working on]
```

Then say "mission control" in any new Claude chat.
