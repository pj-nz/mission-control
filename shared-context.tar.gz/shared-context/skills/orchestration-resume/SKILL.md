---
name: orchestration-resume
description: Resume multi-model orchestration session. Use when PJ uploads shared-context.tar.gz or says "continue orchestration", "resume where we left off", "load the shared context".
---

# Resume Orchestration Session

## Trigger Phrases
- "continue orchestration"
- "resume where we left off"
- "load shared context"
- "pick up the orchestration project"
- Uploads `shared-context.tar.gz`

## Workflow

### Step 1: Extract Context Store
```bash
cd /home/claude
tar -xzvf /mnt/user-data/uploads/shared-context.tar.gz
```

### Step 2: Verify Structure
```bash
ls -la /home/claude/shared-context/
python3 /home/claude/shared-context/load_context.py --list-skills
python3 /home/claude/shared-context/load_context.py --list-projects
```

### Step 3: Check Last State
- Read `/shared-context/memory/decisions.md` for recent decisions
- Read `/shared-context/projects/_active.json` for active projects
- Check project `history.md` files for where we left off

### Step 4: Report Status
Tell PJ:
- What skills are available
- What projects are active
- Last recorded decisions
- Ready to continue

## Key Files
| File | Purpose |
|------|---------|
| `ORCHESTRATION.md` | Who does what, current vs future state |
| `load_context.py` | Context loader utility |
| `skills/_index.json` | Skill routing registry |
| `projects/_active.json` | Active project list |
| `memory/decisions.md` | Decision log for continuity |

## Context Store Location
After extraction: `/home/claude/shared-context/`

## OpenRouter API
PJ provides key at session start or via env var.
Models available: Gemini, Llama 3.1 70B, others via OpenRouter.

## Session Handoff Checklist
Before ending session:
- [ ] Update relevant `project.md` with current state
- [ ] Append to `history.md` with what was done
- [ ] Log decisions to `memory/decisions.md`
- [ ] Re-export: `tar -czvf shared-context.tar.gz shared-context/`
- [ ] Present updated tar to PJ for download
