---
name: linkedin-candidate-card
description: Generate square 1080x1080 LinkedIn candidate profile cards (HTML) from CV/profile data. Use when PJ requests a "LinkedIn card", "candidate card", "profile card for LinkedIn", or wants to promote a candidate on social media. Outputs brand-compliant HTML optimised for LinkedIn feed posts.
---

# LinkedIn Candidate Card Generator

Generate square 1080x1080px candidate profile cards (HTML) for LinkedIn posts from CV/profile data.

## Workflow

### Step 1: Extract Candidate Data
From provided CV/profile, extract:

| Field | Description | Example |
|-------|-------------|---------|
| `role_title` | Anonymised role (no name), can use `<br>` for line break | Senior Azure Migration<br>Architect |
| `specialisation` | 1-line specialty descriptor | Azure Infrastructure & Cloud Migration Specialist |
| `location` | City, Country | Auckland, New Zealand |
| `summary` | 2-3 sentences highlighting key experience, sectors, achievements | Highly experienced Azure architect with 17+ years... |
| `years_experience` | Calculate from CV, format as "X+" | 17+ |
| `demand_level` | HIGH or VERY HIGH based on market context | VERY HIGH |
| `scale_focus` | Enterprise, Mid-Market, or SME | Enterprise |
| `skills` | 4 core competencies (what they do) | Azure Migration, Infrastructure Architecture, DC Transformation, Enterprise Cutover |
| `tools` | 5 technologies (what they use) | Azure NetApp Files, Citrix DaaS, SCCM, Office 365, Active Directory |
| `availability` | Now, 2 wks, 4 wks, etc. | Now |

### Step 2: Generate HTML
Load template from `assets/template.html` and populate all placeholders:

- `{{ROLE_TITLE}}` - Role title (can include `<br>`)
- `{{SPECIALISATION}}` - Specialty line
- `{{LOCATION}}` - Location
- `{{SUMMARY}}` - Bio paragraph
- `{{YEARS_EXPERIENCE}}` - Number with +
- `{{DEMAND_LEVEL}}` - HIGH or VERY HIGH
- `{{SCALE_FOCUS}}` - Enterprise/Mid-Market/SME
- `{{SKILL_1}}` to `{{SKILL_4}}` - Core skills
- `{{TOOL_1}}` to `{{TOOL_5}}` - Technologies
- `{{AVAILABILITY}}` - Availability badge text (e.g., "Available Now", "Available 2 Weeks")

### Step 3: Output
Save populated HTML to `/mnt/user-data/outputs/candidate-card.html` and present to user.

## Template Location
`assets/template.html` - 1080x1080 HTML template with Lexel branding.

## Design Specifications

### Dimensions
- 1080x1080px square (LinkedIn feed optimised)
- 48px padding all sides

### Brand Elements
- Logo: `https://res.cloudinary.com/dhrt0nopd/image/upload/v1764016692/Lexel-RaaS-Logo-RGB_wu4ko9.png` (64px height)
- Primary accent: `#00a6c6` (cyan)
- Text: `#706f73` (dark grey)
- Secondary: `#9f9fa2` (medium grey)
- CTA: `#ff9900` (orange)
- Font: Lexend (Google Fonts)

### Layout Structure
1. **Header**: Logo (left) + Availability badge (right, cyan)
2. **Title section**: Role title (42px bold), specialisation (20px cyan), location (16px grey)
3. **Summary**: 2-3 sentence paragraph (17px light)
4. **Stats row**: 3 boxes - Years Experience, Market Demand, Scale Focus
5. **Skills**: 4 cyan tags
6. **Technologies**: 5 grey tags
7. **CTA footer**: "Interested? Contact Lexel Resourcing" + Orange button

### Visual Accents
- 8px cyan gradient bar on left edge
- Subtle gradient background (white to #f8f9fa)
- 12px border-radius on stat boxes
- 6px border-radius on tags
