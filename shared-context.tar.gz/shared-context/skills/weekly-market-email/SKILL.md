---
name: weekly-market-email
description: Generate weekly "What I'm Seeing This Week" HTML email newsletters for Lexel Resourcing featuring NZ cloud/infrastructure/security market commentary and a featured candidate profile. Use when PJ requests a weekly market email, market signal newsletter, or asks to feature a candidate profile in an email format. Triggers on phrases like "weekly email", "market signal email", "feature this candidate", or "what I'm seeing this week".
---

# Weekly Market Email Generator

Generate brand-compliant HTML email newsletters combining market commentary with a featured candidate profile.

## Workflow

### Step 1: Gather Market Intelligence
Search web for recent (last 7 days) NZ cloud, infrastructure, and security market news:
- Cloud adoption trends (Azure, AWS Auckland region, hybrid/multi-cloud)
- Skills demand and talent market signals
- Infrastructure investment news
- Cybersecurity workforce updates

Write 3 paragraphs of prose commentary (not bullets) synthesising findings relevant to hiring managers.

### Step 2: Process Candidate Profile
Extract from provided CV/profile:
- **Role title**: Anonymised, role-based (e.g., "Senior Cloud Migration Engineer")
- **Specialisation**: 1-line descriptor (e.g., "Azure & Hybrid Infrastructure Specialist")
- **Location**: City, Country
- **Summary**: 2-3 sentences highlighting key experience and sectors
- **Skills**: 4 core competencies (what they do)
- **Tools**: 5 technologies (what they use)
- **Experience**: Years (calculate from CV)
- **Demand level**: HIGH or VERY HIGH based on market context
- **Availability**: Now, 2 wks, etc.

### Step 3: Generate HTML
Load template from `assets/template.html` and populate all placeholders.

**Placeholders:**
- `{{contact_first_name}}` - Leave as placeholder or use "there"
- `{{market_commentary_paragraph_1}}`, `_2`, `_3` - Market prose
- `{{candidate_role_title}}` - Anonymised role
- `{{candidate_specialisation}}` - Specialty line
- `{{candidate_location}}` - Location
- `{{candidate_summary}}` - Bio paragraph
- `{{skill_1}}` to `{{skill_4}}` - Core skills
- `{{tool_1}}` to `{{tool_5}}` - Technologies
- `{{demand_level}}` - HIGH or VERY HIGH
- `{{years_experience}}` - Number with +
- `{{availability}}` - Timeframe

### Step 4: Output
Save populated HTML to `/mnt/user-data/outputs/` and present to user.

## Template Location
`assets/template.html` - Email-safe HTML with Lexel branding, responsive design, MSO conditionals.

## Design Constraints
- 600px max width email container
- Lexend font family with Arial fallback
- Brand colors: #00a6ce (primary), #706f73 (text), #ff9900 (CTA accent), #c2bfb8 (secondary tags)
- Skills/tools use inline-block spans for proper wrapping
- Stats row uses table-layout: fixed with 33.33% widths
- Two CTAs: Orange "Enquire About This Candidate" on profile, Blue "Book a Time to Chat" at footer
