# Orchestration Reference

## Current State: Human-in-the-Loop

**You (PJ):** Driver seat. Decides what gets done, which model, when to approve.

**Claude:** Orchestrator. Matches skills, loads context, calls external models, validates output, presents for review.

**External Models (via OpenRouter):** Executors. Llama, Gemini, etc. do specific tasks when delegated.

---

## Who Does What

### PJ (Human)
| Action | Why |
|--------|-----|
| Initiates tasks | You know what's needed |
| Chooses model overrides | "Use Llama for this" |
| Reviews outputs | Quality gate, catches model judgment errors |
| Approves to commit | Nothing persists without your say |
| Flags patterns | "This works, let's automate it" |

### Claude (Orchestrator)
| Action | Why |
|--------|-----|
| Matches skill from intent | Understands natural language → skill routing |
| Loads context via loader | Knows what context each task needs |
| Calls external models | Has API access, can build prompts |
| Validates outputs | Checks placeholders filled, format correct |
| Compares multi-model outputs | Side-by-side for your review |
| Presents for approval | Surfaces work, doesn't commit without you |
| Appends to history/decisions | Records what was done after approval |

### External Models (Llama, Gemini, etc.)
| Action | Why |
|--------|-----|
| Execute discrete tasks | Specific capabilities (speed, cost, context window) |
| Return structured output | JSON, HTML, Markdown as instructed |
| No memory/state | Stateless - context injected per call |
| No approval authority | Output goes to inbox, not production |

---

## Current Flow

```
PJ: "Make a candidate card for this person"
          │
          ▼
┌─────────────────────────────────────┐
│ Claude (in chat)                    │
│                                     │
│ 1. Parse intent                     │
│ 2. Match skill: linkedin-candidate  │
│ 3. Load context (skill + template)  │
│ 4. Decide model (or ask PJ)         │
│ 5. Call model via OpenRouter        │
│ 6. Validate output                  │
│ 7. Present to PJ                    │
└─────────────────┬───────────────────┘
                  │
                  ▼
PJ: Reviews card, requests changes or approves
          │
          ▼
Claude: Saves to outputs, logs to history
```

---

## Future State: Automated Pipeline

**When to add this:**
- [ ] Patterns proven and repeatable
- [ ] You trust model selection logic
- [ ] You want triggers from outside chat (Slack, n8n, webhook)
- [ ] You're comfortable with async approval queue

### Future Flow

```
Trigger (Slack/n8n/webhook): "Make a candidate card for uploaded CV"
          │
          ▼
┌─────────────────────────────────────┐
│ orchestrate.sh (or n8n workflow)    │
│                                     │
│ 1. Receive input                    │
│ 2. Call load_context.py --match     │
│ 3. Get preferred_model from config  │
│ 4. Build prompt                     │
│ 5. Call OpenRouter                  │
│ 6. Validate output                  │
│ 7. Save to /inbox/ with metadata    │
│ 8. Notify PJ (Slack/email)          │
└─────────────────────────────────────┘
          │
          ▼
PJ: Reviews inbox, approves/rejects
          │
          ▼
Approved items → committed to outputs/projects
```

### Future: orchestrate.sh (Reference Implementation)

```bash
#!/bin/bash
# NOT YET IMPLEMENTED - Reference for when ready

QUERY="$1"
INPUT_FILE="$2"
CONTEXT_ROOT="/path/to/shared-context"

# 1. Match skill
SKILL_MATCH=$(python3 $CONTEXT_ROOT/load_context.py --match "$QUERY" --json)
SKILL_NAME=$(echo $SKILL_MATCH | jq -r '.skill_config.name // empty')
PREFERRED_MODEL=$(echo $SKILL_MATCH | jq -r '.skill_config.preferred_model // "claude"')

if [ -z "$SKILL_NAME" ]; then
    echo "No skill matched for: $QUERY"
    exit 1
fi

# 2. Load context and build prompt
INPUT_CONTENT=$(cat "$INPUT_FILE")
PROMPT=$(python3 $CONTEXT_ROOT/load_context.py \
    --skill "$SKILL_NAME" \
    --no-memory \
    --prompt "$INPUT_CONTENT")

# 3. Map model name to OpenRouter model string
case $PREFERRED_MODEL in
    claude) MODEL="anthropic/claude-3.5-sonnet" ;;
    gemini) MODEL="google/gemini-2.0-flash-001" ;;
    llama)  MODEL="meta-llama/llama-3.1-70b-instruct" ;;
    *)      MODEL="$PREFERRED_MODEL" ;;
esac

# 4. Call OpenRouter
RESPONSE=$(curl -s https://openrouter.ai/api/v1/chat/completions \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer $OPENROUTER_API_KEY" \
    -d "$(jq -n --arg p "$PROMPT" --arg m "$MODEL" \
        '{model:$m, messages:[{role:"user",content:$p}]}')")

OUTPUT=$(echo "$RESPONSE" | jq -r '.choices[0].message.content')

# 5. Save to inbox
TIMESTAMP=$(date +%Y-%m-%d-%H%M%S)
OUTPUT_FILE="$CONTEXT_ROOT/inbox/${TIMESTAMP}-${SKILL_NAME}.html"
echo "$OUTPUT" > "$OUTPUT_FILE"

# 6. Update queue
jq --arg f "$OUTPUT_FILE" --arg s "$SKILL_NAME" --arg m "$MODEL" \
    '.pending += [{file:$f, skill:$s, model:$m, status:"pending_review"}]' \
    "$CONTEXT_ROOT/inbox/_queue.json" > tmp.json && mv tmp.json "$CONTEXT_ROOT/inbox/_queue.json"

# 7. Notify (placeholder)
echo "Output saved to inbox: $OUTPUT_FILE"
echo "Awaiting review."
```

---

## Signals That We're Ready to Automate

| Signal | Status |
|--------|--------|
| Skill matching is reliable | ✅ Tested |
| Context loading works | ✅ Tested |
| Multi-model handoff works | ✅ Tested |
| Output format is consistent | ✅ Tested |
| PJ trusts model selection | ⏳ Building confidence |
| Approval queue exists | ✅ Scaffolded |
| External trigger needed | ⏳ Not yet |
| Patterns are repeatable | ⏳ More reps needed |

---

## Model Selection Logic (For Future Automation)

| Task Type | Preferred | Fallback | Rationale |
|-----------|-----------|----------|-----------|
| Candidate cards | Claude | Gemini | Better narrative, knows Lexel context |
| Market research | Llama | Gemini | Fast, good at structured extraction |
| Large doc processing | Gemini | Claude | Larger context window |
| Battlecards | Claude | Llama | Sandler nuance, strategic thinking |
| Data extraction | Llama | Gemini | Fast, cheap, structured output |
| Creative copy | Claude | - | Voice/tone consistency |

---

## Open Questions Before Automating

1. **Confidence threshold** - When is output good enough to auto-approve?
2. **Error handling** - What happens when model fails/returns garbage?
3. **Cost tracking** - How to monitor token spend across models?
4. **Notification channel** - Slack? Email? In-app?
5. **Rollback** - How to undo a bad commit?

---

## Next Steps (When Ready)

1. Implement `orchestrate.sh` based on reference above
2. Add to n8n as webhook-triggered workflow
3. Connect Slack for notifications
4. Build simple approval UI (or use Notion inbox view)
5. Add confidence scoring for auto-approve threshold

---

*Last updated: 2025-01-21*
*Status: Manual orchestration via Claude chat. Automation deferred until patterns proven.*
