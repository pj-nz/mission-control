# Mission Control

Multi-model orchestration context for Claude.

## Quick Start

**New Claude session:**
1. Say: **"mission control"**
2. Claude pulls this repo and initializes

**Required allowlist domains:**
- `github.com`
- `codeload.github.com`
- `raw.githubusercontent.com`

## Use This Yourself

1. **Fork this repo**
2. Edit `memory/user.md` with your own context
3. Add your own skills to `skills/`
4. Say "mission control" in Claude → it pulls from your fork

## Structure

```
skills/          - Reusable skill definitions
memory/          - User context, entities, decisions
projects/        - Active project state + history
templates/       - Output templates
inbox/           - Approval queue
load_context.py  - Context loader utility
ORCHESTRATION.md - Who does what reference
```

## Key Commands

| Say | Does |
|-----|------|
| "mission control" | Initialize session |
| "list skills" | Show available skills |
| "list projects" | Show active projects |
| "save and close" | Commit, push, backup |

## What This Enables

- **Multi-model orchestration** - Route tasks to different LLMs (Claude, Gemini, Llama) via OpenRouter
- **Shared context** - Skills, memory, and project state accessible to any model
- **Human-in-the-loop** - You review and approve before anything commits

See `ORCHESTRATION.md` for the full architecture.

---

*Originally built by PJ @ Lexel + Claude*
