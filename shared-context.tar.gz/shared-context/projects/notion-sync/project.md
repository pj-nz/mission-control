# Project: Notion ↔ JobAdder Sync

## Status: Active
## Priority: Medium
## Last Touch: 2025-01-21
## Owner: PJ

## Objective
Bidirectional sync between Notion CRM and JobAdder ATS.
- Companies/Contacts created in Notion → pushed to JobAdder
- Candidates/Placements in JobAdder → surfaced in Notion
- Email enrichment via People Data Labs

## Stack
| Component | Tool | Status |
|-----------|------|--------|
| CRM | Notion | ✅ Active |
| ATS | JobAdder | ✅ Connected |
| Automation | n8n | ✅ Workflows built |
| Enrichment | People Data Labs | ✅ API integrated |
| Enrichment | Apollo | ✅ API integrated |

## Current State
- [x] Notion company database schema
- [x] Notion contact database schema
- [x] n8n webhook triggers on Notion changes
- [x] JobAdder API authentication
- [x] PDL enrichment workflow
- [ ] Deduplication logic (company matching)
- [ ] Contact → Candidate promotion flow
- [ ] Error handling / retry logic

## Data Flow
```
Notion Company Created
    ↓
n8n webhook triggered
    ↓
Check JobAdder for existing match
    ↓
If no match → Create in JobAdder
    ↓
Store JobAdder ID back in Notion
```

## Open Questions
1. Matching logic - LinkedIn URL vs Company Name vs Domain?
2. Conflict resolution - which system wins on update?
3. Bulk backfill - how to handle existing records?

## Dependencies
- Notion API access (connected)
- JobAdder API access (connected via Zapier MCP)
- n8n instance on Railway
