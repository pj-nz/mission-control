# Project: Lexel Voice Agent

## Status: Active
## Priority: High
## Last Touch: 2025-01-21
## Owner: PJ

## Objective
Outbound sales voice agent for Lexel with DISC personality adaptation.
Automate initial prospect outreach, qualify interest, book meetings.

## Stack
| Component | Tool | Status |
|-----------|------|--------|
| Voice synthesis | ElevenLabs | ✅ Selected |
| Telephony | Vapi | ✅ Integrated |
| Orchestration | Claude | ✅ Active |
| Prospect data | Notion CRM | 🔄 In progress |
| Call logging | JobAdder | ⏳ Pending |

## Current State
- [x] Vapi account setup
- [x] ElevenLabs voice cloning tested
- [x] Basic call script written
- [ ] Prospect data injection from Notion
- [ ] DISC profile lookup pre-call
- [ ] Call outcome logging to JobAdder
- [ ] Voicemail detection handling

## Open Questions
1. DISC adaptation - pre-call lookup or realtime inference?
2. Voicemail detection - drop message or callback queue?
3. Call recording consent - auto-announce or skip?

## Key Metrics (Target)
- Calls per day: 50+
- Connect rate: >30%
- Meeting book rate: >5%

## Dependencies
- Notion CRM prospect database (needs cleanup)
- JobAdder API access (confirmed)
- DISC profiles in Humantic.ai or similar
