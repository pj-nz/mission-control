# Voice Agent - History Log

Append-only. Newest entries at top.

---

## 2025-01-21 23:00 UTC
**Action:** Project scaffolded in shared context store
**Model:** Claude
**Outcome:** project.md created with current state
**Next:** Wire up Notion prospect lookup

## 2025-01-20 (estimated)
**Action:** Compared ElevenLabs vs PlayHT latency
**Model:** Manual testing
**Outcome:** ElevenLabs 340ms avg vs PlayHT 520ms
**Decision:** Use ElevenLabs for lower latency

## 2025-01-18 (estimated)
**Action:** Evaluated Vapi vs Bland.ai
**Model:** Manual testing
**Outcome:** Vapi has better webhook support, cleaner API
**Decision:** Use Vapi for telephony layer
