#!/usr/bin/env python3
"""
Context Loader for Multi-Model Orchestration
Loads minimal relevant context from shared-context store.
"""

import json
import os
import sys
import argparse
from pathlib import Path

CONTEXT_ROOT = Path("/home/claude/shared-context")

def load_file(path: Path) -> str:
    """Load file contents, return empty string if not found."""
    try:
        return path.read_text()
    except FileNotFoundError:
        return ""

def load_json(path: Path) -> dict:
    """Load JSON file, return empty dict if not found."""
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def match_skill(query: str) -> tuple[str, dict] | None:
    """Match query to skill via triggers. Returns (skill_name, config) or None."""
    index = load_json(CONTEXT_ROOT / "skills" / "_index.json")
    skills = index.get("skills", {})
    
    query_lower = query.lower()
    for skill_name, config in skills.items():
        triggers = config.get("triggers", [])
        for trigger in triggers:
            if trigger.lower() in query_lower:
                return skill_name, config
    return None

def load_context(
    skill: str = None,
    project: str = None,
    include_memory: bool = True,
    include_history: bool = False,
    history_lines: int = 50
) -> dict:
    """
    Load context payload based on requirements.
    
    Returns dict with:
        - user: user memory (if include_memory)
        - skill: skill definition (if skill specified)
        - template: skill template (if skill has one)
        - project: project.md contents (if project specified)
        - history: recent history entries (if include_history)
        - entities: known entities (if include_memory)
        - meta: info about what was loaded
    """
    context = {"meta": {"loaded": []}}
    
    # User memory
    if include_memory:
        user_md = load_file(CONTEXT_ROOT / "memory" / "user.md")
        if user_md:
            context["user"] = user_md
            context["meta"]["loaded"].append("memory/user.md")
        
        entities = load_json(CONTEXT_ROOT / "memory" / "entities.json")
        if entities:
            context["entities"] = entities
            context["meta"]["loaded"].append("memory/entities.json")
    
    # Skill
    if skill:
        index = load_json(CONTEXT_ROOT / "skills" / "_index.json")
        skill_config = index.get("skills", {}).get(skill, {})
        
        if skill_config:
            context["skill_config"] = skill_config
            
            # Load skill definition
            skill_path = skill_config.get("path")
            if skill_path:
                skill_content = load_file(CONTEXT_ROOT / skill_path)
                if skill_content:
                    context["skill"] = skill_content
                    context["meta"]["loaded"].append(skill_path)
            
            # Load template if exists
            template_path = skill_config.get("template")
            if template_path:
                template_content = load_file(CONTEXT_ROOT / template_path)
                if template_content:
                    context["template"] = template_content
                    context["meta"]["loaded"].append(template_path)
    
    # Project
    if project:
        project_md = load_file(CONTEXT_ROOT / "projects" / project / "project.md")
        if project_md:
            context["project"] = project_md
            context["meta"]["loaded"].append(f"projects/{project}/project.md")
        
        if include_history:
            history_md = load_file(CONTEXT_ROOT / "projects" / project / "history.md")
            if history_md:
                # Take last N lines
                lines = history_md.split('\n')
                context["history"] = '\n'.join(lines[-history_lines:])
                context["meta"]["loaded"].append(f"projects/{project}/history.md")
    
    # Calculate sizes
    context["meta"]["total_chars"] = sum(
        len(str(v)) for k, v in context.items() if k != "meta"
    )
    context["meta"]["approx_tokens"] = context["meta"]["total_chars"] // 4
    
    return context

def build_prompt(context: dict, task_input: str) -> str:
    """Build a prompt string from loaded context."""
    parts = []
    
    if context.get("user"):
        parts.append(f"## USER CONTEXT\n{context['user']}")
    
    if context.get("skill"):
        parts.append(f"## SKILL INSTRUCTIONS\n{context['skill']}")
    
    if context.get("template"):
        parts.append(f"## TEMPLATE\n{context['template']}")
    
    if context.get("project"):
        parts.append(f"## PROJECT CONTEXT\n{context['project']}")
    
    if context.get("history"):
        parts.append(f"## RECENT HISTORY\n{context['history']}")
    
    parts.append(f"## TASK INPUT\n{task_input}")
    
    return "\n\n".join(parts)

def list_skills() -> list[dict]:
    """List all available skills."""
    index = load_json(CONTEXT_ROOT / "skills" / "_index.json")
    skills = []
    for name, config in index.get("skills", {}).items():
        skills.append({
            "name": name,
            "description": config.get("description", ""),
            "triggers": config.get("triggers", []),
            "preferred_model": config.get("preferred_model", "claude")
        })
    return skills

def list_projects() -> list[dict]:
    """List all active projects."""
    active = load_json(CONTEXT_ROOT / "projects" / "_active.json")
    return active.get("active", [])

def main():
    parser = argparse.ArgumentParser(description="Load context for multi-model orchestration")
    parser.add_argument("--skill", "-s", help="Skill name to load")
    parser.add_argument("--match", "-m", help="Match skill from query string")
    parser.add_argument("--project", "-p", help="Project name to load")
    parser.add_argument("--no-memory", action="store_true", help="Skip user memory")
    parser.add_argument("--history", action="store_true", help="Include project history")
    parser.add_argument("--history-lines", type=int, default=50, help="Lines of history to include")
    parser.add_argument("--list-skills", action="store_true", help="List available skills")
    parser.add_argument("--list-projects", action="store_true", help="List active projects")
    parser.add_argument("--prompt", help="Task input to build full prompt")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    # List commands
    if args.list_skills:
        skills = list_skills()
        if args.json:
            print(json.dumps(skills, indent=2))
        else:
            for s in skills:
                print(f"• {s['name']}: {s['description']}")
                print(f"  Triggers: {', '.join(s['triggers'])}")
                print(f"  Model: {s['preferred_model']}\n")
        return
    
    if args.list_projects:
        projects = list_projects()
        if args.json:
            print(json.dumps(projects, indent=2))
        else:
            for p in projects:
                print(f"• {p['name']} [{p['status']}] - {p['priority']} priority")
        return
    
    # Match skill from query
    skill = args.skill
    if args.match:
        match = match_skill(args.match)
        if match:
            skill = match[0]
            if not args.json:
                print(f"Matched skill: {skill}", file=sys.stderr)
        else:
            print(f"No skill matched for: {args.match}", file=sys.stderr)
    
    # Load context
    context = load_context(
        skill=skill,
        project=args.project,
        include_memory=not args.no_memory,
        include_history=args.history,
        history_lines=args.history_lines
    )
    
    # Build prompt if task input provided
    if args.prompt:
        prompt = build_prompt(context, args.prompt)
        if args.json:
            context["prompt"] = prompt
        else:
            print(prompt)
            return
    
    # Output
    if args.json:
        print(json.dumps(context, indent=2))
    else:
        print(f"Loaded: {', '.join(context['meta']['loaded'])}")
        print(f"Total: ~{context['meta']['approx_tokens']} tokens")

if __name__ == "__main__":
    main()
