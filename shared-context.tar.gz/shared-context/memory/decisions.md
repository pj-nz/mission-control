# Decision Log

Append-only record of key decisions for cross-session consistency.

---

## 2025-01-21 | Multi-LLM Orchestration Architecture
**Context:** Exploring how to route tasks to different models while sharing context
**Decision:** File-based shared context store with skill index for routing
**Rationale:** Token efficient, any model can read files, portable
**Models involved:** Claude (orchestrator), Gemini (tested), Llama 3.1 70B (tested)

## 2025-01-21 | Shared Context Store Location
**Context:** Where should skills/memory/projects live?
**Decision:** Hybrid approach
- Notion: memory, project status (source of truth, editable)
- File store: skills, templates, inbox, scratch (fast working storage)
- n8n sync job between them
**Rationale:** Best of both - GUI editing in Notion, fast file access for LLMs
