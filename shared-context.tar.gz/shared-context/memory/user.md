# User: PJ

## Role
Enterprise Account Manager, Lexel Systems Limited
18+ years B2B tech recruiting (cloud, infrastructure, security, operations)

## Communication Style
- Direct, no corporate fluff or warm-up language
- Sandler methodology for sales conversations
- Prefers brutally honest feedback over polished responses
- Dry humor, provocative tone in copywriting

## Technical Context
- Building AI automation tools and orchestration systems
- Familiar with n8n, APIs, LLM integrations
- Can read/debug code but prefers no-code where possible

## Response Preferences
- Token efficient - brief unless task requires depth
- No hypothetical or simulated data
- Transparency over completeness
- Show working, explain trade-offs

## Current Focus Areas
- Multi-LLM orchestration (Claude reasoning, Gemini docs, specialized models)
- Voice AI sales agents (ElevenLabs, Vapi)
- Notion CRM ↔ JobAdder sync
- "Talent Infrastructure" positioning for Lexel

## Known Entities
See: /memory/entities.json
